﻿//importing related libraries

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>

//function declarations

void openfile(String filename);
void start_play_withfilter(String filename);
ISR(TIMER0_COMPA_vect );
void pitch_shift();
void start_play_pitch(String filename, byte factor);
ISR(TIMER1_COMPA_vect );




File data_file;

#define cs_pin 4

//pitch_shift
byte pitch_factor=0;
short ocr1a_val;

//low pass filter
volatile int preval=0;

void setup() {
  DDRA = 0xFF; //set PORTA as output
  //DDRC = 0xFF;
  
  
  Serial.begin(9600);
  Serial.println("start!");
  
  if(!SD.begin(cs_pin)){//Initializing SD card
    while(1);//Try again
  }
  
  start_play_pitch("sith.wav",0);
  //start_play_withfilter("sith.wav");
  

}

void loop() {
  

}

void openfile(String filename){
  data_file = SD.open(filename,FILE_READ);
  data_file.seek(44);
}

void start_play_withfilter(String filename){
 openfile(filename);
 noInterrupts();// disable interrupts
 TCCR0B = (1<<WGM02); // CTC Mode
 TCCR0B = (1 << CS01); // Set preScaler to divide by 8
 TIMSK0 = (1 << OCIE0A); // Call ISR when TCNT0 = OCRA0
 OCR0A = 170; // set sample play rate to 8000Hz_124
 interrupts(); // Enable interrupts to generate waveform!
 
}

ISR(TIMER0_COMPA_vect) { // Called when TCNT0 == OCR0A
  if(data_file.available()){
    int v = (int)data_file.read();
    PORTA = 0.3*preval + 0.3*(v);//write data to PORTA using leaky integrator
    preval = v;
  }else{
  PORTA=0;
  data_file.close();
  TIMSK0=0;
  }
    TCNT0 = 0;//set counter again to zero
}

void pitch_shift(){ // function for pitch shifting
  switch(pitch_factor){
    case 4 : ocr1a_val=250; break;
    case 3 : ocr1a_val=200; break;
    case 0 : ocr1a_val=170; break;
    case 1 : ocr1a_val=100; break;
    case 2 : ocr1a_val=75; break; 
  }
}

void start_play_pitch(String filename,byte factor){
 Serial.println("start play pitch");
 pitch_factor=factor;
 openfile(filename);
 pitch_shift();//take the pitch factor
 noInterrupts();// disable interrupts
 TCCR1B = (1<<WGM12); // CTC Mode
 TCCR1B = (1 << CS11); // Set prescaler to divide by 8
 TIMSK1 = (1 << OCIE1A); // Call ISR when TCNT1 = OCRA1
 OCR1A = ocr1a_val; // set sample play rate to 8000Hz_124
 interrupts(); // Enable interrupts to generate waveform!
 
}

ISR(TIMER1_COMPA_vect) { // Called when TCNT1 == OCR1A
  if(data_file.available()){
    PORTA= data_file.read();//write data to PORTA
  }else{
  PORTA=0;
  data_file.close();
  TIMSK1=0;
  }
    TCNT1 = 0;//set counter again to zero
}
