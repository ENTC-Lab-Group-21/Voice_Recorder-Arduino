/*
 * ArduinoCore.cpp
 *
 * Created: 6/9/2021 9:27:32 PM
 * Author : Diluksha
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

